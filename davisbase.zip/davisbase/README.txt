Project 2

Group Gold

Group members: 
Akshay Bhagwan Sonawane(axs180315)
Divya Eluri (dxe180003)
Lokeswari Umakanthan (lxu190000)
Kiran Noolvi (kxn180017)
Lohith Aswathappa(lxa170009)

Steps for terminal:
1) Extract the file and find the DbGroupK.jar file in davisbase\davisbase\DbGroupK.jar
2) Open cmd prompt and run the jar file using java -jar DbGroupK.jar

through IDE:
1)Please run DavisBasePrompt.java(src folder-default package).
--------------------------------------------------------------------------------
Welcome to DavisBaseLite
DavisBaseLite Version v2.1
Group Gold Fall'19

Type 'help;' to display supported commands.
--------------------------------------------------------------------------------

*All commands are case insensitive
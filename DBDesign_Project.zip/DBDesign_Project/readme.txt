1. Extract the .zip file to a desired location.
2. Start the MAMP server.
3. Launch the Open Webstart page.
3. Go to phpMyAdmin and load the library.sql file in the MAMP database.
4. Copy the URL of the phpMyAdmin page and replace it with the ".php" page to be run.
5. The application has been launched.

This application can also be launched in the other terminals or command prompt
1. Extract the .zip file to a desired location.
2. Start the MySQL server. 
3. Open the Command Prompt or terminal and launch the php localhost server.
4. Launch the localhost by giving the command "php -S localhost:4000".
5. Copy the obtained URL and paste in the Internet Browser.
6. Attach the file name to be run eg: "xxx.php" at the end of the URL after localhost.
7. The application has been launched.

The only technical dependency is that the system must support PHP(7.3) and MYSQL. No other extra libraries are required.